async function fetchWeather() {
  const city = document.getElementById("city").value;
  const apiKey = "8c80e095974cadeb505dcbf0d7e324ed"; 
  const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

  const resultDiv = document.getElementById("weatherResult");
  resultDiv.textContent = "Loading...";

  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error("City not found");

    const data = await response.json();
    const { name } = data;
    const { temp } = data.main;
    const { description, icon } = data.weather[0];

    resultDiv.innerHTML = `
      <h2>${name}</h2>
      <p><img src="https://openweathermap.org/img/wn/${icon}@2x.png" alt=""> ${temp}°C - ${description}</p>
    `;
  } catch (error) {
    resultDiv.innerHTML = `<p style="color:red;">${error.message}</p>`;
  }
}
